var app = angular.module("MyApp", []);
 app.controller('Mydata', ['$scope', 'filterFilter', function($scope, filterFilter){
  $scope.data = [ {
    "id": 1,
    "name": "Andrews Phillip",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Sam X Williams"
  },
  {
    "id": 2,
    "name": "Dillard Mauleen",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Andy Anthony"
  },
  {
    "id": 3,
    "name": "Miller Jessica",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Mark Twian"
  },
  {
    "id": 4,
    "name": "Marcus Brownless",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Phillip Melo"
  },
  {
    "id": 5,
    "name": "Jake Peralta",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Andy Anthony"
  },
  {
    "id": 6,
    "name": "Adam Lewy",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Andy Anthony"
  },
  {
    "id": 7,
    "name": "Anthony Hopkins",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Terry Christie"
  },
  {
    "id": 8,
    "name": "Sebastian Vettel",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "George Lecrec"
  },
  {
    "id": 9,
    "name": "John Ralfion",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Andy Anthony"
  },
  {
    "id": 10,
    "name": "Leslie Knope",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "April Ludgate"
  },
  {
    "id": 11,
    "name": "Rom Swanson",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Andrew Bernard"
  },
  {
    "id": 12,
    "name": "Jimothy Halpert",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Jack Ryan"
  },
  {
    "id": 13,
    "name": "Michael Scott",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Prison Mike"
  },
  {
    "id": 14,
    "name": "Walter White",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Albert S Crews"
  },
  {
    "id": 15,
    "name": "Sheldon Cooper",
    "description": "Contrary to popular belief, Lorem",
    "webReference": "Craig McMullam"
  }
  ];

    
  $scope.checkAll = function() {
    angular.forEach($scope.data, function(sel) {
      sel.select = $scope.selectAll;
    });
  }

    $scope.deleteRow = function (x){
      $scope.data.splice($scope.data.indexOf(x), 1);
}

  
  //for selecting and deleting checked items
$scope.remove = function(){
  $scope.data = filterFilter($scope.data, function (x) {
    return !x.select;
  });
}
$scope.add = function(newCompany) {
  $scope.companyData = [
      {
          id: 16,
          name: newCompany.name,
          description: newCompany.description,
          webReference: newCompany.webReference
      }
      ];
  console.log(newCompany);
  console.log($scope.companyData);
  console.log($scope.data);
  $scope.data.push.apply($scope.data, $scope.companyData);
};
}]);


